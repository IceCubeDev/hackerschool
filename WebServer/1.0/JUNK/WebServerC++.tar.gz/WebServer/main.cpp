#include "WebServer.h"

#include <iostream>

int main()
{
    try
    {
        WebServer test;
        test.Start();
    }
    catch (char* error)
    {
        std::cout << error << std::endl;
    }
}
