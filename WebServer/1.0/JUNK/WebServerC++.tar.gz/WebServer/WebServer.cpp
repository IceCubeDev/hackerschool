#include "WebServer.h"

WebServer::WebServer(int port)
{
    // Create server socket
    m_serverSock = socket(AF_INET, SOCK_STREAM, 0);
    if (m_serverSock < 0)
        throw ("Unable to create server socket!\n");

    // Make the socket nonblocking
    int flags;
    flags = fcntl(socket,F_GETFL,0);
    assert(flags != -1);
    fcntl(socket, F_SETFL, flags | O_NONBLOCK);

    // Make it a TCP socket
    bzero((char* ) &m_servAddr, sizeof(m_servAddr));
    m_servAddr.sin_family = AF_INET;
    m_servAddr.sin_addr.s_addr = INADDR_ANY;
    m_servAddr.sin_port = htons(port);
    m_port = port;

    // Bind the server
    if (bind(m_serverSock, (sockaddr*) &m_servAddr,
             sizeof(m_servAddr)) < 0)
    {
        char error[512];
        sprintf(error, "Unable to bind server to port %d\n", port);
        throw (error);
    }

    // Listen for incomming connections
    listen(m_serverSock, 5);
}

WebServer::~WebServer()
{
}

int WebServer::Start()
{
    int client_socket;
    sockaddr_in client_address;
    socklen_t clilen = sizeof(client_address);

    while (true)
    {
        printf("Waiting for client ...");
        client_socket = accept(m_serverSock, (sockaddr*) &client_address,
                    &clilen);

        if (client_socket < 0)
        {
            throw("Error accepting new connection!\n");
        }

        printf("Client has connected!\n");
        printf("Killing client!\n");
        close(client_socket);
    }

    close(m_serverSock);
}
