#ifndef WEBSERVER_H_
#define WEBSERVER_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>

class WebServer
{
    public:
        WebServer(int port=27015);
        ~WebServer();

        int Start();
    private:
        int m_serverSock;
        int m_port;

        sockaddr_in m_servAddr;
};

#endif
